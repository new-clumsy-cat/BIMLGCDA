import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset
from imblearn.over_sampling import RandomOverSampler
from sklearn.preprocessing import StandardScaler
import logging
import time
import random

"""
The CircrnaDataset class is designed to load and preprocess circRNA and disease similarity matrices
along with their association labels. It includes functionality for feature scaling, combination,
balancing via oversampling, and data shuffling. This dataset class can be readily integrated
into PyTorch data pipelines for model training and evaluation.
"""

# def set_seed(seed=42):
#     """Set random seed for reproducibility."""
#     random.seed(seed)
#     np.random.seed(seed)
#     torch.manual_seed(seed)
#     if torch.cuda.is_available():
#         torch.cuda.manual_seed_all(seed)
#         torch.backends.cudnn.deterministic = True
#         torch.backends.cudnn.benchmark = False
#
# set_seed(42)

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

class CircrnaDataset(Dataset):
    def __init__(self, circ_sim_path, disease_sim_path, assoc_path, random_seed=42):
        # Track creation time and seed environment for reproducibility
        self.version = '1.0'
        self.created_time = time.strftime('%Y-%m-%d %H:%M:%S')
        random.seed(random_seed)
        np.random.seed(random_seed)
        torch.manual_seed(random_seed)
        logger.info(f'Initializing CircrnaDataset v{self.version} at {self.created_time}')

        # Load similarity matrices and association labels
        self.circ_sim = pd.read_csv(circ_sim_path, index_col=0).values
        self.disease_sim = pd.read_csv(disease_sim_path, index_col=0).values
        self.association = pd.read_csv(assoc_path, index_col=0).values

        # Validate that association dimensions match circRNA × disease
        assert self.association.shape == (self.circ_sim.shape[0], self.disease_sim.shape[0]), \
            f"Association matrix size {self.association.shape} does not match circRNA {self.circ_sim.shape} and disease {self.disease_sim.shape}"

        # Standardize features
        scaler = StandardScaler()
        circ_features = scaler.fit_transform(self.circ_sim)
        disease_features = scaler.fit_transform(self.disease_sim)
        self.circ_features = circ_features
        self.disease_features = disease_features
        self.labels = self.association.flatten()

        # Combine, balance, and shuffle
        self.features, self.labels = self.balance_and_shuffle(circ_features, disease_features, self.labels)

    def balance_and_shuffle(self, circ_features, disease_features, labels):
        # Combine each circRNA–disease pair with element-wise interaction
        features = []
        for i in range(circ_features.shape[0]):
            for j in range(disease_features.shape[0]):
                # Pad shorter vector to match length
                adjusted = np.pad(disease_features[j],
                                  (0, circ_features.shape[1] - disease_features.shape[1]),
                                  mode='constant')
                combined = np.concatenate([
                    circ_features[i],
                    adjusted,
                    circ_features[i] * adjusted
                ])
                features.append(combined)
        features = np.vstack(features)

        # Oversample minority class to reach 50% positives
        ros = RandomOverSampler(sampling_strategy=0.5, random_state=42)
        features_resampled, labels_resampled = ros.fit_resample(features, labels)
        logger.info(f'Oversampled from {len(labels)} → {len(labels_resampled)} samples')

        # Shuffle
        indices = np.arange(len(labels_resampled))
        np.random.shuffle(indices)
        return features_resampled[indices], labels_resampled[indices]

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        feat  = torch.tensor(self.features[idx], dtype=torch.float32)
        label = torch.tensor(self.labels[idx],   dtype=torch.float32).unsqueeze(0)
        return feat, label

    def summary(self):
        """Print a brief summary of dataset size and class distribution."""
        total = len(self.labels)
        pos = int((self.labels == 1).sum())
        neg = total - pos
        logger.info(f'Dataset summary: {total} samples (positives: {pos}, negatives: {neg})')
