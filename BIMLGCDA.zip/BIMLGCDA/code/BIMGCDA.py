from utils1 import *

import torch
import torch.nn as nn
import torch.optim as optim

"""
The MAML class implements Model-Agnostic Meta-Learning with:
- configurable inner and outer learning rates
- a specified number of inner-loop adaptation steps
- optional gradient clipping for stability
It performs task-specific adaptation in the inner loop and aggregates
gradients across tasks for a meta-update in the outer loop.
"""

class BIMAML:
    def __init__(self, model, inner_lr=1e-5, outer_lr=1e-5, inner_steps=3):
        self.model = model
        self.inner_lr = inner_lr
        self.outer_lr = outer_lr
        self.inner_steps = inner_steps
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.outer_lr, weight_decay=1e-4)

    def inner_update(self, x, y, model_copy):
        criterion = nn.BCELoss()
        optimizer_inner = optim.Adam(model_copy.parameters(), lr=self.inner_lr)  # use Adam for inner loop
        for _ in range(self.inner_steps):
            optimizer_inner.zero_grad()
            outputs = model_copy(x)
            loss = criterion(outputs, y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model_copy.parameters(), max_norm=5)  # gradient clipping
            optimizer_inner.step()

    def adapt(self, train_loader):
        all_grads = [None for _ in self.model.parameters()]
        task_count = 0

        for x, y in train_loader:
            # copy the model for each task
            model_copy = GCN(input_dim=x.shape[1], hidden_dim=128, output_dim=1)
            model_copy.load_state_dict(self.model.state_dict())
            model_copy = model_copy.to(x.device)

            # perform inner-loop adaptation
            self.inner_update(x, y, model_copy)

            # compute meta-loss gradients
            grads = torch.autograd.grad(
                nn.BCELoss()(model_copy(x), y),
                model_copy.parameters(),
                retain_graph=True,
            )
            task_count += 1
            all_grads = [
                (g_old + g_new) if g_old is not None else g_new
                for g_old, g_new in zip(all_grads, grads)
            ]

        # average gradients and perform meta-update
        avg_grads = [(g / task_count) if g is not None else None for g in all_grads]
        self.meta_update(avg_grads)

    def meta_update(self, grads):
        for p, g in zip(self.model.parameters(), grads):
            if g is not None:
                p.grad = g.clone()
        self.optimizer.step()
