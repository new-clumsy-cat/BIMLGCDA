import matplotlib.pyplot as plt
from sklearn.metrics import f1_score, roc_auc_score, accuracy_score, recall_score, average_precision_score, precision_recall_curve, roc_curve
import numpy as np
from matplotlib import cm
import torch
import torch.nn as nn
import torch.optim as optim
import torch_geometric.nn as pyg_nn

class GCN(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(GCN, self).__init__()
        self.conv1 = pyg_nn.GCNConv(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, output_dim)
        self.dropout = nn.Dropout(p=0.2)

    def forward(self, x):
        edge_index = self.create_self_loop_edge_index(x.size(0))
        x = torch.relu(self.conv1(x, edge_index))
        x = self.dropout(x)

        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return torch.sigmoid(x)

    def create_self_loop_edge_index(self, num_nodes):
        edge_index = torch.tensor([[i for i in range(num_nodes)], [i for i in range(num_nodes)]])
        return edge_index

def train_model(model, train_loader, optimizer, criterion, device):
    model.train()
    for features, labels in train_loader:
        features, labels = features.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(features)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

def evaluate_model(model, test_loader, device):
    model.eval()
    preds = []
    true_labels = []
    with torch.no_grad():
        for features, labels in test_loader:
            features = features.to(device)
            outputs = model(features)
            preds.extend(outputs.squeeze().cpu().numpy())
            true_labels.extend(labels.squeeze().numpy())

    preds = np.array(preds)
    preds_binary = (preds > 0.5).astype(int)
    return preds, preds_binary, np.array(true_labels)

def calculate_metrics(true_labels, preds_binary, preds):
    f1 = f1_score(true_labels, preds_binary)
    auc = roc_auc_score(true_labels, preds)
    acc = accuracy_score(true_labels, preds_binary)
    aupr = average_precision_score(true_labels, preds)
    recall = recall_score(true_labels, preds_binary)

    return {
        'F1': f1,
        'AUC': auc,
        'Accuracy': acc,
        'AUPR': aupr,
        'Recall': recall
    }


def plot_roc_all_folds(all_folds_roc, k_folds, stage, filename):
    plt.figure()

    for fold in range(k_folds):
        fpr, tpr, auc = all_folds_roc[fold]

        plt.plot(fpr, tpr, label=f"Fold {fold + 1} (AUC: {auc:.4f})")

    plt.plot([0, 1], [0, 1], linestyle='--', color='gray', label="Random Guess")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title(stage)
    plt.legend()

    plt.savefig(filename, dpi=400, format='eps')
    png_filename = filename.replace('.eps', '.png')
    plt.savefig(png_filename, dpi=400, format='png')
    plt.close()


def plot_pr_all_folds(pr_data, recall_data, k_folds, stage, filename):
    plt.figure()

    for fold in range(k_folds):
        fold_recall_data = recall_data[fold][0]
        fold_pr_data = pr_data[fold][0]

        recall = np.ravel(fold_recall_data)
        precision = np.ravel(fold_pr_data)

        plt.plot(recall, precision, label=f"Fold {fold + 1}")

    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title(stage)
    plt.legend()

    plt.savefig(filename, dpi=400, format='eps')
    png_filename = filename.replace('.eps', '.png')
    plt.savefig(png_filename, dpi=400, format='png')
    plt.close()

